
So this is an application to generate html pages in a specific style. You want a different style? Go open the src folder and do as you like! See the sample file for a look at my stylistic choices. Love them, hate them, one person can maintain them. They can be hosted on github. The whole point is to be able to develop webpages without one of those website generators. 

With all due respect, you probably don't need a ribbon to navigate quickly. If you can get from home to your deepest subpage in three clicks or less, no ribbons. Keep it simple.

I made a webiste with Weebly and then it was bought by sqaure... now I have a website with a functionally different builder app: new UI and UX, pages of steps that looped back on themselves. A popup that demanded sales from a site that was not made for sales. Madness. 

Click the thing called "start" answer some questions, and python will take a generic file, make some text replacements, and output a webpage for you. You can use the Images folder for a logo or for an image gallery.

Top of the page has a logo, title, and two cols: One for describing the project in a paragraph or two, and the other for a list of features and links. The image gallery goes under that. Simple!

Here's the legal stuff: 



Copyright 2023 Andrew Vella

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

