cd src
python3 ./main.py