import traceback
from unidecode import unidecode
import os

#https://www.w3schools.com/css/css_selectors.asp
#https://www.w3schools.com/css/tryit.asp?filename=trycss_image_gallery_responsive
def GenHtml():
	out = intro()
	
	#get inputs
	title = SaulGoodmansPatentedInputFunction("\nGive the page title:\n>")
	if (title.lower() == "sample"):
		sample()
		quit()

	header = SaulGoodmansPatentedInputFunction("\nGive the header:\n>")
	dtitle = SaulGoodmansPatentedInputFunction("\nGive the description title:\n>")
	desc = MultilineInput("\nGive the description:\n>")
	bulletTitle = SaulGoodmansPatentedInputFunction("\nTitle a bulleted list:\n>")
	bulletList = MultilineInput("\nGive a bulleted list with one item per line. Bullets will be added automatically:\n", "-")
	exLinks = SaulGoodmansPatentedInputFunction("\nTitle a a section for external links:\n>")
	linkList = LinkNamer(MultilineInput("\nGive a list of links with one item per line:\n", "<a href=\"", '" target="_blank">Lorem ipsum dolor</a><br>').split("<br>"))

	logoImage = SaulGoodmansPatentedInputFunction("\nGive an image for the logo by file name. Be sure to use a file from the Images directory.:\n>")
	logoAlt = SaulGoodmansPatentedInputFunction("\nGive the alt text for the logo:\n>")

	#make substring replacements
	out = out.replace("<title>Lorem ipsum dolor</title>", "<title>" + title + "</title>")
	out = out.replace("<h2>Lorem ipsum dolor</h2>", "<h2>" + header + "</h2>")
	
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> Lorem ipsum dolor<br><br> Lorem ipsum dolor<br><br> </p>", "<h3>" + dtitle + "</h3> <p>" + desc + "</p>")
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> -Lorem ipsum dolor<br> -Lorem ipsum dolor<br> -Lorem ipsum dolor<br> </p>" , "<h3>" + bulletTitle + "</h3> <p>" + bulletList + "</p>")
	out = out.replace('<h3>Lorem ipsum dolor</h3> <a href="https://andrewjvella.github.io/PersonalHomePage/" target="_blank">Lorem ipsum dolor</a>' , '<h3>' + exLinks + '</h3>' + linkList)
	
	out = out.replace('<img src="Images\\waspFlowers.jpg" alt="Bee and Flower" style="object-fit:contain; width:75px; height:75px;"><br><br><br>', '<img src="Images\\' + logoImage +'" alt="' + logoAlt + '" style="object-fit:contain; width:75px; height:75px;"><br><br><br>')

#Image gallery

	if (input("Would you like to add and image gallery? (y/n)\n>").lower()[0] == "y"):
		out += ImageGal()


	output(out)
	


def ImageGal():

	out = "<h2>Image Gallery</h2>\n"
	pig = ""
	cat = ""
	dog = ""


	while (True):


		cat = SaulGoodmansPatentedInputFunction("Give an image name from the Images directory (no path):\n> ")
		dog = SaulGoodmansPatentedInputFunction("Give an image description:\n> ")


		out += '''
		<div class="responsive">
  		<div class="gallery">
    	<a target="_blank" href="img_5terre.jpg">
      	<img src="Images/''' + cat + '''" alt=" " width="600" height="400">
    	</a>
    	<div class="desc">''' + dog + '''</div>
  		</div>
		</div>

		'''
		pig = input("\nPush enter to add another image to the gallery. Type 'q' to exit this loop.\n> ")
		
		if (pig == "q"):
			break

	out += '\n<div class="clearfix"></div><div style="padding:6px;"></div>'
	return out

def intro(b = True):
	if b:
		print("This program is for quickly writing html pages in a specific style. Enjoy!\n")
	# get generic file content
	f = open("generic.html", "r")
	out = f.read()

	#remove whitespace
	out = out.replace("\r\n", "")
	out = out.replace("\n", "")
	
	f.close()	

	return out 
def output(out):

	out = unidecode(out) #convert all characters into printable characters
	
	outf = open("out.html", "w")
	outf.write(out)
	outf.close()

	os.system("mv out.html ../")

	q = input('"out.html" has been created. Push enter to restart this program.\nType "q" to quit.\n>')

	if (q == "q"):
		quit()


def MultilineInput(message = "", front = "", trail = "\n"):
	print(message + "\n(Type or paste text here. Type '$' to continue)\n\n")
	contents = ""
	line = ""
	while not line == "$":
			line = input(">")
			if line == "$":
				break
			contents += "" + front + line + trail 	

	#newline preservation
	return contents.replace("\r", "").replace("\n","<br>")


def LinkNamer(list):
	i = 0
	while i < len(list) - 1:
		list[i] = list[i].replace("Lorem ipsum dolor", SaulGoodmansPatentedInputFunction("Name link " + str(i + 1) + ":\n>"))
		i = i + 1
	out = ""

	for c in list:
		out += c + "<br>"
	return out


def SaulGoodmansPatentedInputFunction(message):
	t = ""

	while (t == ""):
		t = input(message)
		t = t.strip()
		if (t == ""):
			print("No input was given! Try again.\n")


	return t
	

def sample():

	out = intro(False)


	#https://loremipsum.io/generator/?n=3&t=p
	desc = '''

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Maecenas ultricies mi eget mauris pharetra et. A cras semper auctor neque vitae tempus. Eu lobortis elementum nibh tellus molestie nunc non. Consequat ac felis donec et odio pellentesque diam volutpat commodo. Luctus venenatis lectus magna fringilla urna porttitor rhoncus. Elit ut aliquam purus sit amet luctus venenatis lectus. Ultricies mi eget mauris pharetra et ultrices. Sodales ut eu sem integer vitae. Parturient montes nascetur ridiculus mus mauris vitae ultricies leo. Tortor condimentum lacinia quis vel eros donec ac. Nibh ipsum consequat nisl vel pretium lectus quam. Vivamus arcu felis bibendum ut tristique et egestas quis ipsum. Duis at tellus at urna condimentum mattis. Morbi tincidunt ornare massa eget egestas purus viverra accumsan in. Magna etiam tempor orci eu lobortis elementum nibh tellus molestie.<br><br>

Amet venenatis urna cursus eget. Amet commodo nulla facilisi nullam vehicula ipsum a arcu cursus. Aliquam ultrices sagittis orci a. Et malesuada fames ac turpis egestas integer eget aliquet nibh. Sit amet facilisis magna etiam tempor orci. Pulvinar pellentesque habitant morbi tristique senectus et netus et. Morbi tempus iaculis urna id. Mus mauris vitae ultricies leo. Donec adipiscing tristique risus nec. Ornare aenean euismod elementum nisi quis eleifend.<br><br>


	'''


	#make substring replacements
	out = out.replace("<title>Lorem ipsum dolor</title>", "<title>Sample</title>")
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> Lorem ipsum dolor<br><br> Lorem ipsum dolor<br><br> </p>", "<h3>" + "Lorem ipsum dolor" + "</h3> <p>" + desc + "</p>")
	

	#sample gallery these images have 3 by 2 aspect ratios 
	out += '''
	<br><h2>Image Gallery</h2><br>

<div class="gallery">
  <a target="_blank" href="Images\\cardinal.jpg">
    <img src="Images\\cardinal.jpg" alt="Cardinal poses on a fence.">
  </a>
  <div class="desc">Cardinal poses on a fence.</div>
</div>




<div class="gallery">
  <a target="_blank" href="Images\\catbird.jpg">
    <img src="Images\\catbird.jpg" alt="Catbird poses on a fence.">
  </a>
  <div class="desc">Catbird poses on a fence.</div>
</div>





	'''


	output(out)
	


def main(debug = False):
	while True:
		try:
			if (not debug):
				GenHtml()
			if (debug):
				out = intro()
				d = MultilineInput("Debug mode, give it a whirl:\n>")
				out = out.replace("<h3>Lorem ipsum dolor</h3> <p> Lorem ipsum dolor<br><br> Lorem ipsum dolor<br><br> </p>", "<h3>" + "Test" + "</h3> <p>" + d + "</p>")
				output(out)


		except Exception as e:
			ash = ""

			if debug:
				ash = str(traceback.print_exc())

			input("The following error has happened:\n\n" + str(e) + ash + "\n\nPress Enter to restart the program.\n>")

main(False)