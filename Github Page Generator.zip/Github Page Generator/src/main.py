import traceback
from unidecode import unidecode
import os

#https://www.w3schools.com/css/css_selectors.asp
#https://www.w3schools.com/css/tryit.asp?filename=trycss_image_gallery_responsive
def GenHtml():
	out = intro()
	
	#get inputs
	title = SaulGoodmansPatentedInputFunction("\nGive the page title:\n>")
	if (title.lower() == "sample"):
		sample()
		quit()

	header = SaulGoodmansPatentedInputFunction("\nGive the header:\n>")
	dtitle = SaulGoodmansPatentedInputFunction("\nGive the description title:\n>")
	desc = MultilineInput("\nGive the description:\n>")
	bulletTitle = SaulGoodmansPatentedInputFunction("\nTitle a bulleted list:\n>")
	bulletList = MultilineInput("\nGive a bulleted list with one item per line. Bullets will be added automatically:\n", "-")
	exLinks = SaulGoodmansPatentedInputFunction("\nTitle a a section for external links:\n>")
	linkList = LinkNamer(MultilineInput("\nGive a list of links with one item per line:\n", "<a href=\"", '" target="_blank">Lorem ipsum dolor</a><br>').split("<br>"))

	logoImage = SaulGoodmansPatentedInputFunction("\nGive an image for the logo by file name. Be sure to use a file from the Images directory.:\n>")
	logoAlt = SaulGoodmansPatentedInputFunction("\nGive the alt text for the logo:\n>")

	#make substring replacements
	out = out.replace("<title>Lorem ipsum dolor</title>", "<title>" + title + "</title>")
	out = out.replace("<h2>Lorem ipsum dolor</h2>", "<h2>" + header + "</h2>")
	
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> Lorem ipsum dolor<br><br> Lorem ipsum dolor<br><br> </p>", "<h3>" + dtitle + "</h3> <p>" + desc + "</p>")
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> -Lorem ipsum dolor<br> -Lorem ipsum dolor<br> -Lorem ipsum dolor<br> </p>" , "<h3>" + bulletTitle + "</h3> <p>" + bulletList + "</p>")
	out = out.replace('<h3>Lorem ipsum dolor</h3> <a href="https://andrewjvella.github.io/PersonalHomePage/" target="_blank">Lorem ipsum dolor</a>' , '<h3>' + exLinks + '</h3>' + linkList)
	
	out = out.replace('<img src="Images\\waspFlowers.jpg" alt="Bee and Flower" style="object-fit:contain; width:75px; height:75px;"><br><br><br>', '<img src="Images\\' + logoImage +'" alt="' + logoAlt + '" style="object-fit:contain; width:75px; height:75px;"><br><br><br>')

#Image gallery

	if (input("Would you like to add and image gallery? (y/n)\n>").lower()[0] == "y"):
		out += ImageGal()


	output(out)
	


def ImageGal():

	out = "<h2>Image Gallery</h2>\n"
	pig = ""
	cat = ""
	dog = ""


	while (True):


		cat = SaulGoodmansPatentedInputFunction("Give an image name from the Images directory (no path):\n> ")
		dog = SaulGoodmansPatentedInputFunction("Give an image description:\n> ")



		out += '''
		<div class="responsive">
  		<div class="gallery">
    	<a target="_blank" href="img_5terre.jpg">
      	<img src="Images/''' + cat + '''" alt=" " width="600" height="400">
    	</a>
    	<div class="desc">''' + dog + '''</div>
  		</div>
		</div>

		'''
		pig = input("\nPush enter to add another image to the gallery. Type 'q' to exit this loop.\n> ")
		
		if (pig == "q"):
			break

	out += '\n<div class="clearfix"></div><div style="padding:6px;"></div>'
	return out

def intro(b = True):
	if b:
		print("This program is for quickly writing html pages in a specific style. Enjoy!\n")
	# get generic file content
	f = open("generic.html", "r")
	out = f.read()

	#remove whitespace
	out = out.replace("\r\n", "")
	out = out.replace("\n", "")
	
	f.close()	

	return out 
def output(out):

	out = unidecode(out) #convert all characters into printable characters
	
	outf = open("out.html", "w")
	outf.write(out)
	outf.close()

	os.system("mv out.html ../")

	q = input('"out.html" has been created. Push enter to restart this program.\nType "q" to quit.\n>')

	if (q == "q"):
		quit()


def MultilineInput(message = "", front = "", trail = "\n"):
	print(message + "\n(Type or paste text here. Type '$' to continue)\n\n")
	contents = ""
	line = ""
	while not line == "$":
			line = input(">")
			if line == "$":
				break
			contents += "" + front + line + trail 	

	#newline preservation
	return contents.replace("\r", "").replace("\n","<br>")


def LinkNamer(list):
	i = 0
	while i < len(list) - 1:
		list[i] = list[i].replace("Lorem ipsum dolor", SaulGoodmansPatentedInputFunction("Name link " + str(i + 1) + ":\n>"))
		i = i + 1
	out = ""

	for c in list:
		out += c + "<br>"
	return out


def SaulGoodmansPatentedInputFunction(message):
	t = ""

	while (t == ""):
		t = input(message)
		t = t.strip()
		if (t == ""):
			print("No input was given! Try again.\n")


	return t
	

def sample():

	out = intro(False)

	linkList = '<a href="https://github.com/AndrewJVella/Page-Generator/raw/main/Github%20Page%20Generator.zip" target="_blank">Download This Project</a><br><a href="https://github.com/AndrewJVella/Page-Generator" target="_blank">See the Github</a>'


	#https://loremipsum.io/generator/?n=3&t=p
	desc = '''


So this is an application to generate html pages in a specific style. You want a different style? Go open the src folder and do as you like! See the sample file for a look at my stylistic choices. Love them, hate them, one person can maintain them. They can be hosted on github. The whole point is to be able to develop webpages without one of those website generators. 
<br><br>
After downloading, click the thing called "start", answer some questions, and python will take a generic file, make some text replacements, and output a webpage for you. You can use the Images folder for a logo or for an image gallery.
<br><br>
Top of the page has a logo, title, and two columns: one for describing the project in a paragraph or two, and the other for a list of features and links. The image gallery goes under that. Simple!
<br><br>
Copyright 2023 Andrew Vella

	'''


	#make substring replacements
	out = out.replace("<title>Lorem ipsum dolor</title>", "<title>Github Page Generator</title>")
	out = out.replace("<h2>Lorem ipsum dolor</h2>", "<h2>Github Page Generator</h2>")
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> Lorem ipsum dolor<br><br> Lorem ipsum dolor<br><br> </p>", "<h3>How it Works</h3> <p>" + desc + "</p>")
	out = out.replace("<h3>Lorem ipsum dolor</h3> <p> -Lorem ipsum dolor<br> -Lorem ipsum dolor<br> -Lorem ipsum dolor<br> </p>" , "<h3>Features</h3> <p>-Logo<br>-Responsive Image Gallery<br>-Sample File</p>")
	out = out.replace('<h3>Lorem ipsum dolor</h3> <a href="https://andrewjvella.github.io/PersonalHomePage/" target="_blank">Lorem ipsum dolor</a>' , '<h3>Links</h3>' + linkList)



	

	#sample gallery these images have 3 by 2 aspect ratios 
	out += '''
	<br><h2>Image Gallery</h2><br>

<div class="gallery">
  <a target="_blank" href="Images\\cardinal.jpg">
    <img src="Images\\cardinal.jpg" alt="Cardinal poses on a fence.">
  </a>
  <div class="desc">Cardinal poses on a fence.</div>
</div>




<div class="gallery">
  <a target="_blank" href="Images\\catbird.jpg">
    <img src="Images\\catbird.jpg" alt="Catbird poses on a fence.">
  </a>
  <div class="desc">Catbird poses on a fence.</div>
</div>





	'''


	output(out)
	


def main(debug = False):
	while True:
		try:
			if (not debug):
				GenHtml()
			if (debug):
				out = intro()
				d = MultilineInput("Debug mode, give it a whirl:\n>")
				out = out.replace("<h3>Lorem ipsum dolor</h3> <p> Lorem ipsum dolor<br><br> Lorem ipsum dolor<br><br> </p>", "<h3>" + "Test" + "</h3> <p>" + d + "</p>")
				output(out)


		except Exception as e:
			ash = ""

			if debug:
				ash = str(traceback.print_exc())

			input("The following error has happened:\n\n" + str(e) + ash + "\n\nPress Enter to restart the program.\n>")

main(False)